JOKE WEBSITE - Sara Baker
--------------------------------------
Built using JS, HTML , CSS and using a my sql Databse
--------------------------------------
Deployment Instructions
_________________________
we need to add the sql database this can be done by executing the sql file on 
the  SQL server.

Then alter the SQL server settings this can be found in ......


